export interface IRestaurant{
  id:number,
  name:string,

//  resturantCategories: null,
//  products: null,
//  "resturantCities": null,
//  "applicationUserId": "2946b9f6-35f7-4e2f-8c2a-7a0ab10885db",
//  "applicationUser": null,
//  "reviews": null
}
