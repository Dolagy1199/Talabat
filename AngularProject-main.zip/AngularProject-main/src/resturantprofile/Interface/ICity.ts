export interface ICity
{
  resturentCityID:number,
  id:number,
  cityName:string,
  delivaryFee:number,
  delivaryTime:string
}
