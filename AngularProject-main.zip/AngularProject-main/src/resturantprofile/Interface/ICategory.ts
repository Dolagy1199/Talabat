export interface ICategory
{
  resturentCategoryID :number,
  id:number,
  catergoryName:string,
}
