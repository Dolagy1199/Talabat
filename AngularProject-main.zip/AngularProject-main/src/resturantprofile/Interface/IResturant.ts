export interface ICustomer {
  UserName:string,
  Password:string,
  Email:string,
  ImageNameFile:string,
  MinOrderAmmount:number,
  WorkingHours:number,
}
