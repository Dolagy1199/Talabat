import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profiletabs',
  templateUrl: './profiletabs.component.html',
  styleUrls: ['./profiletabs.component.scss']
})
export class ProfiletabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
