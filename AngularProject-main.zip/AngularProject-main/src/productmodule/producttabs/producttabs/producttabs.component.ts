import { Component, Input, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-producttabs',
  templateUrl: './producttabs.component.html',
  styleUrls: ['./producttabs.component.scss']
})
export class ProducttabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
