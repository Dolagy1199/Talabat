import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bread-crmb',
  templateUrl: './bread-crmb.component.html',
  styleUrls: ['./bread-crmb.component.scss']
})
export class BreadCrmbComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
