export interface ICategory {
        "id":number,
        "name":string,
        "isDeleted":boolean
        
       
    }
