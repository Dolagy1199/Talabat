export interface IReview
{
    text:string,
    resturantId:number,
    date:Date,
    customer?:any
}