export interface ICart
{
  cartID:number,
  productID:number,
  productName:string,
  totalPrice:number,
  quantity:number,
  delivaryFee:number
  customerAddress:string,

}

