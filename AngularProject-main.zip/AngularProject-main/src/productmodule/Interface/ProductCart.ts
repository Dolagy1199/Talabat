export interface IProductCart {
  "id":number,
  "name":string,
  "price":number,
  "quanttity":number,
  "resturantID": number,
  "applicationUser":string,
  "deliveryfee":number

}
