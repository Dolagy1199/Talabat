export interface ICategorySelectedResturant {
    "id":number,
    "categoryID":number,
    "category":[
      {
        "id":number;
        "name":string,
        "isDeleted":boolean,
      }
    ]
    
   
}






