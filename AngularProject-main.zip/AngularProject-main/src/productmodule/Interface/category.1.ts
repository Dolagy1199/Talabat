type category = {
    id: number;
    name: string;
    isDeleted: boolean;

};
